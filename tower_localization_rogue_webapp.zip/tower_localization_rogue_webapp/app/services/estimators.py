import numpy as np
from scipy.optimize import least_squares
from .simulate import ta_to_distance
def multilateration_least_squares(rx_xy, d_est):
    def residuals(x):
        return np.linalg.norm(rx_xy - x, axis=1) - d_est
    x0 = rx_xy.mean(axis=0)
    res = least_squares(residuals, x0)
    return res.x
def intersect_bearings(rx_xy, bearings_deg):
    thetas = np.radians(bearings_deg)
    A = []; b = []
    for (x, y), th in zip(rx_xy, thetas):
        ux = np.sin(th); uy = np.cos(th)
        A.append([-uy, ux]); b.append(ux*y - uy*x)
    A = np.array(A); b = np.array(b)
    est, *_ = np.linalg.lstsq(A, b, rcond=None)
    return est.flatten()
def ta_multilateration(rx_xy, ta_units):
    d_est = ta_to_distance(ta_units)
    return multilateration_least_squares(rx_xy, d_est)
def fuse_estimates(est_list, variances):
    w = np.array([1.0/max(v,1e-6) for v in variances])
    return sum(wi*ei for wi,ei in zip(w, est_list)) / w.sum()
