import numpy as np
R_EARTH = 6371000.0
def latlon_to_xy(lat, lon, lat0, lon0):
    dlat = np.radians(lat - lat0)
    dlon = np.radians(lon - lon0)
    x = R_EARTH * dlon * np.cos(np.radians((lat + lat0) / 2.0))
    y = R_EARTH * dlat
    return x, y
def xy_to_latlon(x, y, lat0, lon0):
    lat = lat0 + (y / R_EARTH) * 180.0 / np.pi
    lon = lon0 + (x / (R_EARTH * np.cos(np.radians(lat0)))) * 180.0 / np.pi
    return lat, lon
