import os, psycopg2
from contextlib import contextmanager
def get_db_url(): return os.getenv("DATABASE_URL","").strip()
@contextmanager
def get_conn():
    url = get_db_url()
    if not url: raise RuntimeError("DATABASE_URL not set")
    conn = psycopg2.connect(url); 
    try: yield conn
    finally: conn.close()
def ensure_schema():
    url = get_db_url()
    if not url: return False
    with get_conn() as conn:
        cur = conn.cursor()
        try: cur.execute("CREATE EXTENSION IF NOT EXISTS postgis;"); conn.commit()
        except Exception: conn.rollback()
        cur.execute("""
        CREATE TABLE IF NOT EXISTS towers (
            id SERIAL PRIMARY KEY,
            mcc INTEGER, mnc INTEGER, lac_tac INTEGER, cell_id BIGINT UNIQUE,
            lon DOUBLE PRECISION, lat DOUBLE PRECISION, range_m DOUBLE PRECISION,
            samples INTEGER, avg_signal_stren DOUBLE PRECISION, geom geometry(Point,4326)
        );""")
        try: cur.execute("CREATE INDEX IF NOT EXISTS towers_gix ON towers USING GIST (geom);")
        except Exception: conn.rollback()
        conn.commit()
    return True
def upsert_tower(cur, row):
    cur.execute("""
        INSERT INTO towers (mcc,mnc,lac_tac,cell_id,lon,lat,range_m,samples,avg_signal_stren,geom)
        VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s, ST_SetSRID(ST_MakePoint(%s,%s),4326))
        ON CONFLICT (cell_id) DO UPDATE SET lon=EXCLUDED.lon, lat=EXCLUDED.lat,
            range_m=EXCLUDED.range_m, samples=EXCLUDED.samples,
            avg_signal_stren=EXCLUDED.avg_signal_stren, geom=EXCLUDED.geom;
    """, (int(row["mcc"]), int(row["net"]), int(row["LAC/TAC"]), int(row["cell ID"]),
          float(row["long"]), float(row["lat"]), float(row.get("range(m)",0) or 0),
          int(row.get("samples",0) or 0), float(row.get("avgSignalStren",-99) or -99),
          float(row["long"]), float(row["lat"])))
