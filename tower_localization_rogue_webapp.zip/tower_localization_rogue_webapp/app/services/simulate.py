import numpy as np
def rsrp_to_distance(rsrp_dbm, P0_dbm=-30.0, n=3.0, d0=1.0):
    return d0 * 10 ** ((P0_dbm - rsrp_dbm) / (10.0 * n))
def ta_to_distance(ta_units):
    return 78.0 * ta_units
def simulate_measurements(rogue_xy, rx_xy, tx_power_dbm=-30.0, n=3.0,
                          rsrp_noise_db=3.0, ta_noise_units=0.5, aoa_noise_deg=5.0,
                          include_rsrq=True, include_rssi=True):
    N = rx_xy.shape[0]
    d = np.linalg.norm(rx_xy - rogue_xy, axis=1)
    P0 = tx_power_dbm
    rsrp = P0 - 10.0 * n * np.log10(np.maximum(d, 1.0))
    rsrp += np.random.normal(0.0, rsrp_noise_db, size=N)
    ta = d / 78.0 + np.random.normal(0.0, ta_noise_units, size=N)
    dx = rogue_xy[0] - rx_xy[:,0]
    dy = rogue_xy[1] - rx_xy[:,1]
    bearing = np.degrees(np.arctan2(dx, dy))
    bearing += np.random.normal(0.0, aoa_noise_deg, size=N)
    out = {'rsrp_dbm': rsrp, 'ta_units': ta, 'aoa_deg': bearing, 'distance_true': d}
    if include_rssi:
        rssi = rsrp + 6.0 + np.random.normal(0, 2.0, size=N)
        out['rssi_dbm'] = rssi
    if include_rsrq:
        rsrq = -3.0 + 0.1*(rsrp + 80.0) + np.random.normal(0, 1.0, size=N)
        out['rsrq_db'] = rsrq
    return out
def gen_probe_ring(center_xy, r=300.0, k=8):
    angles = np.linspace(0, 2*np.pi, k, endpoint=False)
    return np.vstack([center_xy + np.column_stack([r*np.cos(angles), r*np.sin(angles)])])
