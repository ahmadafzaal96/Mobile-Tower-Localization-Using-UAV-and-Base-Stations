import os, json
STATE_PATH = os.getenv("ROGUE_STATE_PATH", "data/rogue_state.json")
def save_state(state: dict):
    os.makedirs(os.path.dirname(STATE_PATH), exist_ok=True)
    with open(STATE_PATH, 'w') as f: json.dump(state, f)
def load_state() -> dict:
    if os.path.exists(STATE_PATH):
        with open(STATE_PATH, 'r') as f: return json.load(f)
    return {}
def clear_state():
    if os.path.exists(STATE_PATH): os.remove(STATE_PATH)
