import json, os, numpy as np
from dataclasses import dataclass
CONFIG_PATH = os.getenv("CALIBRATION_CONFIG", "data/calibration.json")
@dataclass
class PathLossParams:
    P0_dbm: float = -30.0
    n: float = 3.0
def save_params(params: PathLossParams):
    os.makedirs(os.path.dirname(CONFIG_PATH), exist_ok=True)
    with open(CONFIG_PATH, 'w') as f:
        json.dump({"P0_dbm": params.P0_dbm, "n": params.n}, f)
def load_params() -> PathLossParams:
    if os.path.exists(CONFIG_PATH):
        with open(CONFIG_PATH, 'r') as f:
            j = json.load(f)
        return PathLossParams(P0_dbm=float(j.get("P0_dbm", -30.0)), n=float(j.get("n", 3.0)))
    return PathLossParams()
def fit_pathloss(rsrp_dbm: np.ndarray, distances_m: np.ndarray) -> PathLossParams:
    x = np.log10(np.maximum(distances_m, 1.0)); y = rsrp_dbm
    A = np.vstack([np.ones_like(x), -10.0*x]).T
    theta, *_ = np.linalg.lstsq(A, y, rcond=None)
    return PathLossParams(P0_dbm=float(theta[0]), n=float(theta[1]))
