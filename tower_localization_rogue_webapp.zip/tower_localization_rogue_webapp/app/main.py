import os
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from starlette.responses import FileResponse
from dotenv import load_dotenv
from .routers.localization import router as localization_router

load_dotenv()
app = FastAPI(title="Rogue Tower Localization", version="0.2.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])
static_dir = os.path.join(os.path.dirname(__file__), 'static')
app.mount("/static", StaticFiles(directory=static_dir), name="static")
app.include_router(localization_router)

@app.get("/")
def index():
    return FileResponse(os.path.join(static_dir, "index.html"))
