from fastapi import APIRouter, Body
from fastapi.responses import JSONResponse
import os, json, numpy as np, pandas as pd
from ..services.geodesy import latlon_to_xy, xy_to_latlon
from ..services.simulate import simulate_measurements, rsrp_to_distance, gen_probe_ring
from ..services.estimators import multilateration_least_squares, intersect_bearings, ta_multilateration, fuse_estimates
from ..services.calibration import load_params, save_params, fit_pathloss, PathLossParams
from ..services.db import get_db_url, get_conn, ensure_schema, upsert_tower
from ..services import rogue_state

router = APIRouter(prefix="/api", tags=["localization"])

def _load_towers():
    url = get_db_url()
    if url:
        with get_conn() as conn:
            cur = conn.cursor()
            cur.execute("SELECT mcc,mnc,lac_tac,cell_id,lon,lat,range_m,samples,avg_signal_stren FROM towers LIMIT 10000;")
            rows = cur.fetchall()
        if rows:
            return pd.DataFrame(rows, columns=['mcc','net','LAC/TAC','cell ID','long','lat','range(m)','samples','avgSignalStren'])
    csv_path = os.getenv("CSV_PATH", "data/pak_tower.csv")
    return pd.read_csv(csv_path)

def _towers_to_geojson(df: pd.DataFrame):
    feats = []
    for _, r in df.iterrows():
        feats.append({"type":"Feature","properties":{"mcc":int(r["mcc"]),"net":int(r["net"]),"lac_tac":int(r["LAC/TAC"]),"cell_id":int(r["cell ID"])},
                      "geometry":{"type":"Point","coordinates":[float(r["long"]), float(r["lat"])]}})
    return {"type":"FeatureCollection","features":feats}

def _aoi_bbox(df: pd.DataFrame):
    return float(df['lat'].min()), float(df['lat'].max()), float(df['long'].min()), float(df['long'].max())

def _random_point_in_bbox(lat_min, lat_max, lon_min, lon_max, rng=None):
    rng = rng or np.random.default_rng()
    return rng.uniform(lat_min, lat_max), rng.uniform(lon_min, lon_max)

@router.get("/towers")
def towers():
    df = _load_towers()
    return JSONResponse(_towers_to_geojson(df))

@router.post("/db/ingest_csv")
def ingest_csv(csv_path: str = None):
    url = get_db_url()
    if not url: return JSONResponse({"error":"DATABASE_URL not set"}, status_code=400)
    ensure_schema()
    import os
    csv_path = csv_path or os.getenv("CSV_PATH","data/pak_tower.csv")
    if not os.path.exists(csv_path): return JSONResponse({"error":f"CSV not found: {csv_path}"}, status_code=404)
    df = pd.read_csv(csv_path)
    with get_conn() as conn:
        cur = conn.cursor()
        for _, row in df.iterrows():
            upsert_tower(cur, row)
        conn.commit()
    return {"ok": True, "rows": int(df.shape[0])}

@router.post("/calibrate")
def calibrate(payload: dict = Body(...)):
    rsrp = np.array(payload.get("rsrp_dbm", []), dtype=float)
    dist = np.array(payload.get("distances_m", []), dtype=float)
    if rsrp.size == 0 or dist.size == 0 or rsrp.size != dist.size:
        return JSONResponse({"error":"Provide equal-length arrays: rsrp_dbm and distances_m"}, status_code=400)
    params = fit_pathloss(rsrp, dist); save_params(params)
    return {"ok": True, "params": {"P0_dbm": params.P0_dbm, "n": params.n}}

@router.post("/rogue/init")
def rogue_init(payload: dict = Body(...)):
    df = _load_towers()
    lat_min, lat_max, lon_min, lon_max = _aoi_bbox(df)
    lat = payload.get("lat", None); lon = payload.get("lon", None)
    if lat is None or lon is None: lat, lon = _random_point_in_bbox(lat_min, lat_max, lon_min, lon_max)
    state = {
        "ids": {"mcc": int(payload.get("mcc", df.iloc[0]['mcc'])), "net": int(payload.get("net", df.iloc[0]['net'])),
                "lac_tac": int(payload.get("lac_tac", df.iloc[0]['LAC/TAC'])), "cell_id": int(payload.get("cell_id", 999999)),
                "psc_pci": int(payload.get("psc_pci", 0))},
        "tx_power_dbm": float(payload.get("tx_power_dbm", -30.0)),
        "true_lat": float(lat), "true_lon": float(lon),
        "debug_truth": bool(payload.get("debug_truth", False))
    }
    rogue_state.save_state(state)
    return {"ok": True, "ids": state["ids"]}

@router.post("/rogue/measure")
def rogue_measure(payload: dict = Body(...)):
    st = rogue_state.load_state()
    if not st: return JSONResponse({"error":"Initialize rogue first via /api/rogue/init"}, status_code=400)
    df = _load_towers()
    center_lat, center_lon = float(df['lat'].mean()), float(df['long'].mean())
    rogue_xy = np.array(latlon_to_xy(st["true_lat"], st["true_lon"], center_lat, center_lon))
    towers_from_csv = bool(payload.get("towers_from_csv", True))
    max_receivers = int(payload.get("max_receivers", 50))
    rx_xy_list, rx_meta = [], []
    if towers_from_csv:
        use_df = df.sample(min(max_receivers, len(df)), random_state=42) if len(df) > max_receivers else df.copy()
        for _, row in use_df.iterrows():
            x, y = latlon_to_xy(row['lat'], row['long'], center_lat, center_lon)
            rx_xy_list.append([x, y])
            rx_meta.append({"type":"tower","lat":float(row['lat']),"lon":float(row['long']),"cell_id":int(row["cell ID"])})
    pr = payload.get("probe_ring", None)
    if pr:
        ring = gen_probe_ring(np.array(latlon_to_xy(st["true_lat"], st["true_lon"], center_lat, center_lon)), r=float(pr.get("r",300.0)), k=int(pr.get("k",8)))
        for x,y in ring:
            rx_xy_list.append([float(x),float(y)])
            lat, lon = xy_to_latlon(x, y, center_lat, center_lon)
            rx_meta.append({"type":"probe","lat":float(lat),"lon":float(lon)})
    if not rx_xy_list: return JSONResponse({"error":"No receivers selected."}, status_code=400)
    rx_xy = np.array(rx_xy_list, dtype=float)
    rsrp_noise_db = float(payload.get("rsrp_noise_db", 3.0))
    aoa_noise_deg = float(payload.get("aoa_noise_deg", 5.0))
    ta_noise_units = float(payload.get("ta_noise_units", 0.5))
    meas = simulate_measurements(rogue_xy, rx_xy, tx_power_dbm=float(st["tx_power_dbm"]), rsrp_noise_db=rsrp_noise_db, aoa_noise_deg=aoa_noise_deg, ta_noise_units=ta_noise_units)
    return {"ok": True, "ids": st["ids"], "receivers": rx_meta, "measurements": {k:(v.tolist() if hasattr(v,'tolist') else v) for k,v in meas.items()}}

@router.post("/rogue/estimate")
def rogue_estimate(payload: dict = Body(...)):
    df = _load_towers()
    center_lat, center_lon = float(df['lat'].mean()), float(df['long'].mean())
    recv = payload.get("receivers", [])
    if not recv: return JSONResponse({"error":"Provide receivers list."}, status_code=400)
    rx_xy = []
    for r in recv:
        if "x" in r and "y" in r: rx_xy.append([float(r["x"]), float(r["y"])])
        else:
            x,y = latlon_to_xy(float(r["lat"]), float(r["lon"]), center_lat, center_lon); rx_xy.append([x,y])
    rx_xy = np.array(rx_xy, dtype=float)
    meas = payload.get("measurements", {})
    if not meas: return JSONResponse({"error":"Provide measurements dict."}, status_code=400)
    ests, vars_ = [], []
    if "rsrp_dbm" in meas:
        pl = load_params(); d_est = rsrp_to_distance(np.array(meas["rsrp_dbm"], dtype=float), P0_dbm=pl.P0_dbm, n=pl.n)
        ests.append(multilateration_least_squares(rx_xy, d_est)); vars_.append(float(payload.get("weights",{}).get("rsrp", 1000.0)))
    if "ta_units" in meas:
        ests.append(ta_multilateration(rx_xy, np.array(meas["ta_units"], dtype=float))); vars_.append(float(payload.get("weights",{}).get("ta", 200.0)))
    if "aoa_deg" in meas:
        ests.append(intersect_bearings(rx_xy, np.array(meas["aoa_deg"], dtype=float))); vars_.append(float(payload.get("weights",{}).get("aoa", 50.0)))
    if not ests: return JSONResponse({"error":"No usable measurement arrays provided."}, status_code=400)
    est_xy = fuse_estimates(ests, vars_); est_lat, est_lon = xy_to_latlon(float(est_xy[0]), float(est_xy[1]), center_lat, center_lon)
    return {"type":"FeatureCollection","features":[{"type":"Feature","properties":{"label":"estimate"},"geometry":{"type":"Point","coordinates":[est_lon, est_lat]}}]}

@router.get("/rogue/state")
def rogue_state_view(debug: bool = False):
    st = rogue_state.load_state()
    if not st: return {"ok": False, "state": None}
    out = {"ok": True, "ids": st.get("ids", {}), "tx_power_dbm": st.get("tx_power_dbm", -30.0)}
    if debug and st.get("debug_truth", False): out["truth"] = {"lat": st["true_lat"], "lon": st["true_lon"]}
    return out
