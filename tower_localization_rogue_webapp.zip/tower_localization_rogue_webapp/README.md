# Rogue Tower Localization Webapp

Workflow:
1) **Init Rogue** — Create a rogue tower with IDs (MCC/MNC/LAC/CellID/PCI), no lat/lon; if not provided, random inside AOI.
2) **Measure** — Use known receivers (towers from CSV + optional probe UEs) to collect observables: RSRP/RSSI/RSRQ/TA/AoA.
3) **Estimate** — Fuse measurements (RSRP, TA, AoA) to estimate the rogue location.

Run:
```
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --reload
# open http://localhost:8000
```

Optional:
- `DATABASE_URL=postgres://user:pass@host:5432/db` to enable Postgres ingest (`POST /api/db/ingest_csv`).
- Calibrate path-loss via `POST /api/calibrate` with your (distance, RSRP) pairs.
