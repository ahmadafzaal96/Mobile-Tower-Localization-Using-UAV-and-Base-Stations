#!/usr/bin/env python3
import os, argparse, csv, psycopg2
def via_db(db_url, csv_path):
    conn = psycopg2.connect(db_url); cur = conn.cursor()
    try: cur.execute("CREATE EXTENSION IF NOT EXISTS postgis;"); conn.commit()
    except Exception: conn.rollback()
    cur.execute("""
    CREATE TABLE IF NOT EXISTS towers (
        id SERIAL PRIMARY KEY, mcc INTEGER, mnc INTEGER, lac_tac INTEGER, cell_id BIGINT UNIQUE,
        lon DOUBLE PRECISION, lat DOUBLE PRECISION, range_m DOUBLE PRECISION, samples INTEGER,
        avg_signal_stren DOUBLE PRECISION, geom geometry(Point,4326)
    );""")
    try: cur.execute("CREATE INDEX IF NOT EXISTS towers_gix ON towers USING GIST (geom);")
    except Exception: conn.rollback()
    conn.commit()
    with open(csv_path,'r',encoding='utf-8') as f:
        reader = csv.DictReader(f); count=0
        for row in reader:
            cur.execute("""
                INSERT INTO towers (mcc,mnc,lac_tac,cell_id,lon,lat,range_m,samples,avg_signal_stren,geom)
                VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s, ST_SetSRID(ST_MakePoint(%s,%s),4326))
                ON CONFLICT (cell_id) DO UPDATE SET lon=EXCLUDED.lon, lat=EXCLUDED.lat,
                    range_m=EXCLUDED.range_m, samples=EXCLUDED.samples, avg_signal_stren=EXCLUDED.avg_signal_stren, geom=EXCLUDED.geom;
            """, (int(row["mcc"]), int(row["net"]), int(row["LAC/TAC"]), int(row["cell ID"]),
                  float(row["long"]), float(row["lat"]), float(row.get("range(m)",0) or 0), int(row.get("samples",0) or 0),
                  float(row.get("avgSignalStren",-99) or -99), float(row["long"]), float(row["lat"])))
            count += 1
            if count % 1000 == 0: conn.commit(); print("Ingested", count)
    conn.commit(); print("Done. Rows:", count); cur.close(); conn.close()
if __name__=="__main__":
    ap=argparse.ArgumentParser()
    ap.add_argument('--db', required=True)
    ap.add_argument('--csv', default='data/pak_tower.csv')
    a=ap.parse_args()
    via_db(a.db, a.csv)
